﻿// DarkOne v2.1 Global Script
// Code by tedGo

var configPath = fb.FoobarPath + "DarkOne21\\";
var btn_font = gdi.Font("Tahoma", 11, 0);
var dsp_font = gdi.Font("DarkOne", 19, 0);
var ui_type = window.InstanceType;
var ww = 0; wh = 0;

// ----- CREATE RGB(A) ----------------------------------------------
function RGBA(r, g, b, a) {
	return ((a << 24) | (r << 16) | (g << 8) | (b));
}

// ----- CREATE CUSTOM COLOUR ---------------------------------------
function CustomColour(colour){
	tempc = colour.split("-");
	return ((tempc[3] << 24) | (tempc[0]<<16) | (tempc[1]<<8) | (tempc[2]));
}

// ----- GET UI COLOURS ---------------------------------------------
function get_colors() {
	ui_backcol = ui_type == 0 ? window.GetColorCUI(3) : window.GetColorDUI(1);
	ui_textcol = ui_type == 0 ? window.GetColorCUI(0) : window.GetColorDUI(0);
	ui_btntxtcol = ui_type == 0 ? window.GetColorCUI(2) : window.GetColorDUI(0);
}

get_colors();

function on_colors_changed() {
	get_colors();
	window.Repaint();
}